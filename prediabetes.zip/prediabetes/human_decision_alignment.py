import pandas as pd
import os
import csv
import numpy as np

# set up working dictionary
os.chdir("/Users/james/Desktop/Intervention_prediabetes/Search_with_PROSPERO/Clean/Run2")

# Set the prefix
# the suffix is "SPICE_2_preAI_exclude.csv" or "DRR_2_preAI_exclude.csv" or "DRR_2.csv" or "human_final.csv" or "AI_human_final.csv"
## create the file name for Juice_SPICE_2_preAI_exclude.csv
prefix = 'prediabetes'

suffix_preAI_exclude = 'PICOS_DR_preAI_exclude.csv'
suffix_AI_final = 'PICOS_DR.csv'
suffix_human_final = 'human_final.csv'
suffix_AI_human_final = 'AI_human_final.csv'

preAI_exclude_path = prefix + '_' + suffix_preAI_exclude
AI_final_path = prefix + '_' + suffix_AI_final
human_final_path = prefix + '_' + suffix_human_final
AI_human_final_path = prefix + '_' + suffix_AI_human_final

# load the data
## preAI excluded data in the stage 1 
preAI_exclude = pd.read_csv(preAI_exclude_path)
## AI final data in the stage 2
AI_final = pd.read_csv(AI_final_path)
## Human decision data
human_final = pd.read_csv(human_final_path)

### add a "id" column to the human_final data in the first column if it does not have one
if 'id' not in human_final.columns:
    human_final.insert(0, 'id', range(0, len(human_final)))
### extract the "id" and "Human_Decision" columns from the human_final data
human_final_2 = human_final[['id', 'Human_Decision']]

# merge all of these data together 
## reset the index
preAI_exclude_12 = preAI_exclude.reset_index(drop=True)
AI_final = AI_final.reset_index(drop=True)
AI_complete = pd.concat([preAI_exclude_12, AI_final], axis=0)
## sort by the id column
AI_complete_2 = AI_complete.sort_values(by=['id'])

# reorder the "Reasoning", "Exclusion_reason", "Decision" columns to "Decision", "Exclusion_reason", "Reasoning" columns
AI_complete_3 = AI_complete_2[['id', 'title', 'abstract', 'Population', 'Intervention', 'Comparison', 'Outcome', 'Study_type', 'Decision', 'Rationale']]

# rename the column names from "Decision" to "AI_Decision" and from "Rationale" to "AI_Rationale"
AI_complete_4 = AI_complete_3.rename(columns={'Decision': 'AI_Decision', 'Rationale': 'AI_Rationale'})
## reset the index
AI_complete_4 = AI_complete_4.reset_index(drop=True)

# check which rows have difierent id in the AI_complete_4 and human_final_2 data
## extract the "id" column from the AI_complete_4 data
AI_complete_4_id = AI_complete_4[['id']]
## extract the "id" column from the human_final_2 data
human_final_2_id = human_final_2[['id']]
## compare the "id" column between AI_complete_4 and human_final_2 data
# Elements in df1 not in df2
diff_id = human_final_2_id[~human_final_2_id['id'].isin(AI_complete_4_id['id'])]
# if diff_id is not empty, throw error
if len(diff_id) != 0:
    raise ValueError('The id column in the AI_complete_4 and human_final_2 data are not the same.')


# merge the AI_complete_4 and human_final_2 data by the "id" column
AI_human_comparison = pd.merge(AI_complete_4, human_final_2, on='id')

# save the data
# AI_human_comparison.to_csv('VIA_HPV_Pap_smear_SRMA_AI_human_comparison.csv', index=False)

# Calculate the percentage of 'Full_text_include' in Human_Decision that have corresponding 'Include' in AI_Decision in the same row
## Total 'Full_text_include' in Human_Decision
total_human_full_text_include = len(AI_human_comparison[AI_human_comparison['Human_Decision'] == 'Full_text_include'])
## Total rows where both Human_Decision is 'Full_text_include' and AI_Decision is 'Include'
total_same_row_full_text_include = len(AI_human_comparison[(AI_human_comparison['Human_Decision'] == 'Full_text_include') & (AI_human_comparison['AI_Decision'] == 'Include')])
## Calculate the percentage
AI_full_text_include_accuracy = (total_same_row_full_text_include / total_human_full_text_include) * 100

# Calculate the percentage of 'Title_abstract_exclude' in Human_Decision that have corresponding 'Exclude' in AI_Decision in the same row
## Total 'Title_abstract_exclude' in Human_Decision
total_human_title_abstract_exclude = len(AI_human_comparison[AI_human_comparison['Human_Decision'] == 'Title_abstract_exclude'])
## Total rows where both Human_Decision is 'Title_abstract_exclude' and AI_Decision is 'Exclude'
total_same_row_title_abstract_exclude = len(AI_human_comparison[(AI_human_comparison['Human_Decision'] == 'Title_abstract_exclude') & (AI_human_comparison['AI_Decision'] == 'Exclude')])
## Calculate the percentage
AI_title_abstract_exclude_accuracy = (total_same_row_title_abstract_exclude / total_human_title_abstract_exclude) * 100

# Add the AI_full_text_include_accuracy and AI_title_abstract_exclude_accuracy to the AI_human_comparison data
AI_human_comparison['AI_full_text_include_accuracy'] = AI_full_text_include_accuracy
AI_human_comparison['AI_title_abstract_exclude_accuracy'] = AI_title_abstract_exclude_accuracy

# Keep only the first row of AI_full_text_include_accuracy and AI_title_abstract_exclude_accuracy column
AI_human_comparison.loc[1:, ['AI_full_text_include_accuracy', 'AI_title_abstract_exclude_accuracy']] = None

# save the data
AI_human_comparison.to_csv(AI_human_final_path, index=False)